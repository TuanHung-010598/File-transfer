﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Client
{
    public partial class Form1 : Form
    {
        private Listener listener;
        private TransferClient transferClient;
        private string outputFolder;
        private Timer tmrOverallProg;

        private bool serverRunning;
        public Form1()
        {
            InitializeComponent();
            //btnConnect.Click += new EventHandler(btnConnect_Click);
            //btnStartServer.Click += new EventHandler(btnStartServer_Click);
            //btnStopServer.Click += new EventHandler(btnStopServer_Click);
            //btnSendFile.Click += new EventHandler(btnSendFile_Click);
            //btnPauseTransfer.Click += new EventHandler(btnPauseTransfer_Click);
            //btnStopTransfer.Click += new EventHandler(btnStopTransfer_Click);
            //btnOpenDir.Click += new EventHandler(btnOpenDir_Click);
            //btnClearComplete.Click += new EventHandler(btnClearComplete_Click);

            //btnStopServer.Enabled = false;
            listener = new Listener();
            listener.Accepted += Listener_Accepted;
            tmrOverallProg = new Timer();
            tmrOverallProg.Interval = 1000;
            tmrOverallProg.Tick += TmrOverallProg_Tick;

            outputFolder = "Transfers";
            if(!Directory.Exists(outputFolder))
            {
                Directory.CreateDirectory(outputFolder);
            }
            btnStopServer.Enabled = false;
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            deregisterEvent();
            base.OnFormClosing(e);
        }

        private void TmrOverallProg_Tick(object sender, EventArgs e)
        {
            if (transferClient == null)
                return;
            progressOverall.Value = transferClient.GetOverallProgress();
        }

        private void Listener_Accepted(object sender, SocketAcceptedEventArgs e)
        {
            if(InvokeRequired)
            {
                Invoke(new SocketAcceptedHandler(Listener_Accepted), sender, e);
                return;
            }
            listener.Stop();
            transferClient = new TransferClient(e.Accepted);
            transferClient.OutputFolder = outputFolder;
            registerEvent();
            transferClient.Run();
            tmrOverallProg.Start();
            setConnectionStatus(transferClient.EndPoint.Address.ToString());

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            if(transferClient == null)
            {
                transferClient = new TransferClient();
                transferClient.Connect(txtCntHost.Text.Trim(), Int32.Parse(txtCntPort.Text.Trim()), connectCallback);
                Enabled = false;
            }
            else
            {
                transferClient.Close();
                transferClient = null;
            }
        }
        private void connectCallback(object sender, string error)
        {
            if(InvokeRequired)
            {
                Invoke(new ConnectCallback(connectCallback),sender, error);
                return;
            }
            Enabled = true;
            if(error != null)
            {
                transferClient.Close();
                transferClient = null;
                MessageBox.Show(error, "Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            registerEvent();
            transferClient.OutputFolder = outputFolder;
            transferClient.Run();
            setConnectionStatus(transferClient.EndPoint.Address.ToString());
            tmrOverallProg.Start();
            btnConnect.Text = "Disconnect";
        }
        private void registerEvent()
        {
            transferClient.Complete += TransferClient_Complete;
            transferClient.Disconnected += TransferClient_Disconnected;
            transferClient.ProgressChanged += TransferClient_ProgressChanged;
            transferClient.Queued += TransferClient_Queued;
            transferClient.Stoped += TransferClient_Stoped;
        }
        private void deregisterEvent()
        {
            if (transferClient == null)
                return;
            transferClient.Complete -= TransferClient_Complete;
            transferClient.Disconnected -= TransferClient_Disconnected;
            transferClient.ProgressChanged -= TransferClient_ProgressChanged;
            transferClient.Queued -= TransferClient_Queued;
            transferClient.Stoped -= TransferClient_Stoped;
        }
        private void setConnectionStatus(string connectedTo)
        {
            lblConnected.Text = $"Connection : {connectedTo}";
        }
        private void TransferClient_Stoped(object sender, TransferQueue queue)
        {
            if(InvokeRequired)
            {
                Invoke(new TransferEventHandler(TransferClient_Stoped), sender, queue);
                return;
            }
            lstTransfers.Items[queue.ID.ToString()].Remove();
        }

        private void TransferClient_Queued(object sender, TransferQueue queue)
        {
            if(InvokeRequired)
            {
                Invoke(new TransferEventHandler(TransferClient_Queued), sender, queue);
                return;
            }

            if (transferClient == null)
                return;

            ListViewItem i = new ListViewItem();
            i.Text = queue.ID.ToString();
            i.SubItems.Add(queue.FileName);
            i.SubItems.Add(queue.Type == QueueType.Download ? "Download" : "Upload");
            i.SubItems.Add("0%");
            i.Tag = queue;
            i.Name = queue.ID.ToString();
            lstTransfers.Items.Add(i);
            i.EnsureVisible();

            if(queue.Type == QueueType.Download)
            {
                transferClient.StartTransfer(queue);
            }
        }

        private void TransferClient_ProgressChanged(object sender, TransferQueue queue)
        {
            if(InvokeRequired)
            {
                Invoke(new TransferEventHandler(TransferClient_ProgressChanged), sender, queue);
                return;
            }
            lstTransfers.Items[queue.ID.ToString()].SubItems[3].Text = $"{queue.Progress}%";

        }

        private void TransferClient_Disconnected(object sender, EventArgs e)
        {
            if (InvokeRequired)
            {
                Invoke(new EventHandler(TransferClient_Disconnected), sender, e);
                return;
            }
            deregisterEvent();

            foreach (ListViewItem item in lstTransfers.Items)
            {
                TransferQueue queue = item.Tag as TransferQueue;
                queue.Close();
            }
            lstTransfers.Items.Clear();
            progressOverall.Value = 0;

            transferClient = null;
            setConnectionStatus("-");

            if(serverRunning)
            {
                listener.Start(Int32.Parse(txtCntPort.Text.Trim()));
                setConnectionStatus("Waiting...");
            }
            else
            {
                btnConnect.Text = "Connect";
            }
        }

        private void TransferClient_Complete(object sender, TransferQueue queue)
        {
            throw new NotImplementedException();
        }

        private void btnStartServer_Click(object sender, EventArgs e)
        {
            if (serverRunning)
                return;
            serverRunning = true;
            try
            {
                listener.Start(Int32.Parse(txtCntPort.Text.Trim()));
                setConnectionStatus("Waiting...");
                btnStartServer.Enabled = false;
                btnStopServer.Enabled = true;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, $"Unable listen on port {Int32.Parse(txtCntPort.Text.Trim())}", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnStopServer_Click(object sender, EventArgs e)
        {
            if(!serverRunning)
            {
                return;
            }
            if (transferClient != null)
                transferClient.Close();
            listener.Stop();
            tmrOverallProg.Stop();
            setConnectionStatus("-");
            serverRunning = false;
            btnStartServer.Enabled = true;
            btnStopServer.Enabled = false;
        }

        private void btnSendFile_Click(object sender, EventArgs e)
        {
            if (transferClient == null)
                return;
            using(OpenFileDialog o = new OpenFileDialog())
            {
                o.Filter = "All files (*.*)| *.*";
                o.Multiselect = true;
                if(o.ShowDialog() == DialogResult.OK)
                {
                    foreach (string file in o.FileNames)
                    {
                        transferClient.QueueTransfer(file);
                    }
                }
            }
        }

        private void btnPauseTransfer_Click(object sender, EventArgs e)
        {
            if(transferClient == null)
            {
                return;
            }
            foreach (ListViewItem item in lstTransfers.SelectedItems)
            {
                TransferQueue queue = item.Tag as TransferQueue;
                queue.Client.PauseTransfer(queue);
            }
        }

        private void btnStopTransfer_Click(object sender, EventArgs e)
        {
            if (transferClient == null)
                return;

            foreach (ListViewItem item in lstTransfers.SelectedItems)
            {
                TransferQueue queue = item.Tag as TransferQueue;
                queue.Client.PauseTransfer(queue);
                item.Remove();
            }
            progressOverall.Value = 0;

        }

        private void btnOpenDir_Click(object sender, EventArgs e)
        {
            using(FolderBrowserDialog fb = new FolderBrowserDialog())
            {
                if(fb.ShowDialog() == DialogResult.OK)
                {
                    outputFolder = fb.SelectedPath;
                    if(transferClient != null)
                    {
                        transferClient.OutputFolder = outputFolder;
                    }
                    txtSaveDir.Text = outputFolder;
                }
            }
        }

        private void btnClearComplete_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem item in lstTransfers.Items)
            {
                TransferQueue queue = item.Tag as TransferQueue;
                if(queue.Progress == 100 || !queue.Running)
                {
                    item.Remove();
                }
            }
        }

        private void txtSaveDir_Click(object sender, EventArgs e)
        {
            Process p = new Process();
            p.StartInfo.FileName = "Transfers";
            p.Start();
        }
    }
}
